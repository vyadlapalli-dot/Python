#!/usr/bin/env python
# coding: utf-8

# In[3]:


import csv
import numpy as np
from scipy import optimize
from datetime import datetime
from scipy.optimize import curve_fit

input1 ='20200309_SPX_opt_quotedata.txt'
input2 = ['03/20/2020', '03/31/2020', '04/17/2020', '05/15/2020', '06/19/2020', '06/30/2020', '07/17/2020', '08/21/2020', '09/18/2020', '09/30/2020', '10/16/2020', '11/20/2020', '12/18/2020', '12/31/2020', '3/19/2021', '6/19/2021', '12/17/2021']

def model(k,a,b,rho,m,sigma):
    return a+b*(rho*(k-m)+np.sqrt((k-m)**2+sigma**2))

def fit(input1,listed):
    spx = np.recfromcsv(input1,skip_header=2)
    b = open(input1, "r").readlines()
    line1 = b[0].split(",") 
    S = float(line1[1])
    spx_mar = [[i['strike'],i['iv'],i['iv_1']] for i in spx];
    count=0
    index=0
    for line in b:
        count += 1
        if count > 3:
            parts = line.split(",")
            spx_mar[index].append(parts[0])
            index+=1

    today=datetime.strptime('03/19/2020',"%m/%d/%Y")
    totVar = []
    moneyness = []

    for j in range (0, len(input2)):
        totVar.append([])
        moneyness.append([])
        for i in range(0, len(spx_mar)):
            if input2[j]==spx_mar[i][3]:
                spx_mar[i].append(float(((datetime.strptime(spx_mar[i][3],"%m/%d/%Y")-today).days)/365))
                totVar[j].append((((spx_mar[i][1]/100+spx_mar[i][2]/100)/2)**2)*spx_mar[i][4]*100)
                moneyness[j].append(np.log(spx_mar[i][0]/S))


# In[ ]:




