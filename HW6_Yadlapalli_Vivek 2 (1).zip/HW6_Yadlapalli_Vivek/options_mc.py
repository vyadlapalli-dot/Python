#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np

def CallPrice(S0,K,tau,sigma,r,d):
    NumPaths = input('Enter Number of Sample Paths.')
    NumPeriods = input('Enter Number of Periods.')
    
    if NumPaths == 'DEF':
        NumPaths = 1000
    else:
        NumPaths = int(NumPaths)
    if NumPeriods == 'DEF':
        NumPeriods = 10
    else:
        NumPeriods = int(NumPeriods)
    
    SatT = []
    dS = []
    
    dt = tau/NumPeriods
    
    for i in range(NumPaths):
        SatT.append(S0)
        dS.append(0)
    
    
    for t in range(NumPeriods):
        E = np.random.normal(0,1,NumPaths)
        
        for i in range(NumPaths):
            #SatT[i] = SatT[i]*np.exp((r-0.5*sigma*sigma)*dt+sigma*E[i]*np.sqrt(dt))
            dS[i] = SatT[i]*(r*dt+sigma*E[i]*np.sqrt(dt))
            SatT[i] = SatT[i] + dS[i]
    
    PayOff = []
    for S in SatT:
        PayOff.append(max(0,S-K))
    

    return (np.mean(PayOff))*np.exp(-tau*r)

def PUTPrice(S0,K,tau,sigma,r,d):
    NumPaths = input('Enter Number of Sample Paths.')
    NumPeriods = input('Enter Number of Periods.')
    
    if NumPaths == 'DEF':
        NumPaths = 1000
    else:
        NumPaths = int(NumPaths)
    if NumPeriods == 'DEF':
        NumPeriods = 10
    else:
        NumPeriods = int(NumPeriods)
    
    SatT = []
    dS = []
    
    dt = tau/NumPeriods
    
    for i in range(NumPaths):
        SatT.append(S0)
        dS.append(0)
    
    
    for t in range(NumPeriods):
        E = np.random.normal(0,1,NumPaths)
        
        for i in range(NumPaths):
            #SatT[i] = SatT[i]*np.exp((r-0.5*sigma*sigma)*dt+sigma*E[i]*np.sqrt(dt))
            dS[i] = SatT[i]*(r*dt+sigma*E[i]*np.sqrt(dt))
            SatT[i] = SatT[i] + dS[i]
    
    PayOff = []
    for S in SatT:
        PayOff.append(max(0,K-S))
    

    return (np.mean(PayOff))*np.exp(-tau*r)
        
def CallGreeks(S0,K,tau,sigma,rf,d):
    
    Vt = CallPrice(S0,K,tau,sigma,rf,d)
    #Delta Gamma
    VtpDVt = CallPrice(S0+0.0001,K,tau,sigma,rf,d) 
    

    Delta = (VtpDVt-Vt)/0.0001
    
    Delta2 = (CallPrice(S0+0.0001,K,tau,sigma,rf,d)-VtpDVt)/0.0001
    
    Gamma = (Delta2-Delta)/(0.0001)
    
    #Vega
    VtpDVt = CallPrice(S0,K,tau,sigma+0.0001,rf,d) 
    
    Vega = (VtpDVt-Vt)/0.0001
    
    #Theta
    VtpDVt = CallPrice(S0,K,tau+0.0001,sigma,rf,d) 
    
    Theta = (VtpDVt-Vt)/0.0001
    
    #Rho
    VtpDVt = CallPrice(S0,K,tau,sigma,rf+0.0001,d) 
    
    Rho = (VtpDVt-Vt)/0.0001
        
    return Delta,Gamma,Vega,Theta,Rho
    
    
def PutGreeks(S0,K,tau,sigma,rf,d):
    
    Vt = PutPrice(S0,K,tau,sigma,rf,d)
    #Delta Gamma
    VtpDVt = CallPrice(S0+0.1,K,tau,sigma,rf,d) 
    

    Delta = (VtpDVt-Vt)/0.1
    
    Delta2 = (CallPrice(S0+0.2,K,tau,sigma,rf,d)-VtpDVt)/0.1
    
    Gamma = (Delta2-Delta)/(0.1)
    
    #Vega
    VtpDVt = CallPrice(S0,K,tau,sigma+0.1,rf,d) 
    
    Vega = (VtpDVt-Vt)/0.1
    
    #Theta
    VtpDVt = CallPrice(S0,K,tau+0.1,sigma,rf,d) 
    
    Theta = (VtpDVt-Vt)/0.1
    
    #Rho
    VtpDVt = CallPrice(S0,K,tau,sigma,rf+0.05,d) 
    
    Rho = (VtpDVt-Vt)/0.05
        
    return Delta,Gamma,Vega,Theta,Rho

