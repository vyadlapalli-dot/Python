#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np

def CallBarrierOptionPrice(S0,K,H,tau,sigma,rf,d):
    NumPaths = 1000
    NumPeriods = 1000
    dt = tau/NumPeriods
    if H >= S0 and H >= K:
        
        SatT = []
        dS = []
        
        for i in range(NumPaths):
            SatT.append(S0)
            dS.append(0)
        
        for t in range(NumPeriods):
            
            E = np.random.normal(0,1,NumPaths)
            
            for i in range(NumPaths):  
                
                if SatT[i] != -1:
                    dS[i] = SatT[i]*(rf*dt+sigma*E[i]*np.sqrt(dt))
                    SatT[i] = SatT[i] + dS[i]
                
            
                if SatT[i]>=H:
                    SatT[i] = -1
                elif SatT[i] < H and SatT[i] != -1:
                    continue
        PayOff = []
        for S in SatT:
            if S==-1:
                S=0
            PayOff.append(max(0,S-K))
        return np.mean(PayOff)*np.exp(-rf*tau)
        
    elif H <= S0:
        SatT = []
        dS = []
        
        for i in range(NumPaths):
            SatT.append(S0)
            dS.append(0)
        
        for t in range(NumPeriods):
            E = np.random.normal(0,1,NumPaths)
            
            for i in range(NumPaths):  
                
                if SatT[i] != -1:
                    dS[i] = SatT[i]*(rf*dt+sigma*E[i]*np.sqrt(dt))
                    SatT[i] = SatT[i] + dS[i]
            
                if SatT[i]<=H:
                    SatT[i] = -1
                elif SatT[i] > H:
                    continue
        PayOff = []
        for S in SatT:
            if S==-1:
                S = 0
            
            PayOff.append(max(0,S-K))
            
        return np.mean(PayOff)*np.exp(-rf*tau)
def PutBarrierOptionPrice(S0,K,H,tau,sigma,rf,d):
    NumPaths = 1000
    NumPeriods = 1000
    dt = tau/NumPeriods
    if H >= S0 and H >= K:
        
        SatT = []
        dS = []
        
        for i in range(NumPaths):
            SatT.append(S0)
            dS.append(0)
        
        for t in range(NumPeriods):
            
            E = np.random.normal(0,1,NumPaths)
            
            for i in range(NumPaths):  
                
                if SatT[i] != -1:
                    dS[i] = SatT[i]*(rf*dt+sigma*E[i]*np.sqrt(dt))
                    SatT[i] = SatT[i] + dS[i]
                
            
                if SatT[i]>=H:
                    SatT[i] = -1
                elif SatT[i] < H and SatT[i] != -1:
                    continue
        PayOff = []
        for S in SatT:
            if S==-1:
                S=0
            PayOff.append(max(0,K-S))
        return np.mean(PayOff)*np.exp(-rf*tau)
        
    elif H <= S0:
        SatT = []
        dS = []
        
        for i in range(NumPaths):
            SatT.append(S0)
            dS.append(0)
        
        for t in range(NumPeriods):
            E = np.random.normal(0,1,NumPaths)
            
            for i in range(NumPaths):  
                
                if SatT[i] != -1:
                    dS[i] = SatT[i]*(rf*dt+sigma*E[i]*np.sqrt(dt))
                    SatT[i] = SatT[i] + dS[i]
            
                if SatT[i]<=H:
                    SatT[i] = -1
                elif SatT[i] > H:
                    continue
        PayOff = []
        for S in SatT:
            if S==-1:
                S = 0
            
            PayOff.append(max(0,K-S))
            
        return np.mean(PayOff)*np.exp(-rf*tau)

