#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import math
import numpy as np
import sympy
import math
from sympy.solvers import nsolve

#Numerical N(x)
def NofX(x):
    return 0.5*(1+math.erf(x/(math.sqrt(2))))

#Symbolic N(x)
def SymNofX(x):
    return 0.5*(1+sympy.erf(x/(np.sqrt(2))))


             ########### Calls ##########

####### Numericals ######    
#Numerical Call Price
def CallPrice(S,K,t,sigma,r,d):
    d1 = (math.log(S/K)+t*(r-d+0.5*sigma*sigma))/(sigma*math.sqrt(t))
    d2 = d1 - sigma*math.sqrt(t)
    Nd1 = NofX(d1)
    Nd2 = NofX(d2)
    return S*np.exp(-d*t)*Nd1-K*np.exp(-r*t)*Nd2

def impCallVol(S,K,tau,rf,CallQuote):
    cVol = sympy.Symbol('cVol')
    Cd1 = (sympy.ln(S/K)+(rf+(cVol**2)/2)*tau)/(cVol*sympy.sqrt(tau))
    Cd2 = Cd1 - cVol*sympy.sqrt(tau)
    Nd1 = 0.5*(1+sympy.erf(Cd1/sympy.sqrt(2)))
    Nd2 = 0.5*(1+sympy.erf(Cd2/sympy.sqrt(2)))
    Call = S*Nd1-K*sympy.exp(-rf*tau)*Nd2
    return sympy.nsolve(Call-CallQuote,cVol,0.001)

#######Symbolics 
#Symbolic Call Price
def SymCallPrice(S,K,t,sigma,r,d):
    d1 = (sympy.log(S/K)+t*(r-d+0.5*sigma*sigma))/(sigma*sympy.sqrt(t))
    d2 = d1 - sigma*sympy.sqrt(t)
    Nd1 = SymNofX(d1)
    Nd2 = SymNofX(d2)
    return S*sympy.exp(-d*t)*Nd1-K*sympy.exp(-r*t)*Nd2


def CallGreeks(S0,K,tau,sigma,rf,d):
    
    print(S0,K,tau,sigma,rf,d)
    
    SymK,SymS0,SymTau,SymSigma,SymRf,SymD = sympy.symbols('K S0 tau sigma rf d')
    OptionPrice = SymCallPrice(SymS0,SymK,SymTau,SymSigma,SymRf,SymD)
    
    Delta = diff(OptionPrice,SymS0)
    print(Delta.subs({SymS0 : 100,SymK : 100,SymTau : 1,SymSigma : 0.3,SymRf : 0,SymD : 0}))
    Gamma = diff(Delta,SymS0)
    Vega = diff(OptionPrice,SymSigma)
    Theta = -diff(OptionPrice,SymTau)
    Rho = diff(OptionPrice,SymRf)
    
    
    Del = Delta.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    print(Del)
    Gam = Gamma.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    Veg = Vega.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    Thet = Theta.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    Rh = Rho.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    
    return N(Del),N(Gam),N(Veg),N(Thet),N(Rh)



    
    
           ############# Puts #########
        
####### Numericals

#Nuemrical Put Price
def PutPrice(S,K,t,sigma,r,d):
    d1 = (math.log(S/K)+t*(r-d+0.5*sigma*sigma))/(sigma*math.sqrt(t))
    d2 = d1 - sigma*math.sqrt(t)
    Nd1 = NofX(-d1)
    Nd2 = NofX(-d2)
    return K*math.exp(-r*t)*Nd2-S*math.exp(-d*t)*Nd1

#Numerical Put Volatility    
def impPutVol(S,K,tau,rf,PutQuote):
    
    pVol = sympy.Symbol('pVol')
    Pd1 = (sympy.ln(S/K)+(rf+(pVol**2)/2)*tau)/(pVol*sympy.sqrt(tau))
    Pd2 = Pd1 - pVol*sympy.sqrt(tau)
    Nmd1 = 0.5*(1+sympy.erf(-Pd1/sympy.sqrt(2)))
    Nmd2 = 0.5*(1+sympy.erf(-Pd2/sympy.sqrt(2)))
    Put = K*sympy.exp(-rf*tau)*Nmd2-S*Nmd1
    
    return sympy.nsolve(Put-PutQuote,pVol,0.001)


####Symbolics#######
#Symbolic Put Price
def SymPutPrice(S,K,t,sigma,r,d):
    d1 = (sympy.log(S/K)+t*(r-d+0.5*sigma*sigma))/(sigma*sympy.sqrt(t))
    d2 = d1 - sigma*sympy.sqrt(t)
    Nd1 = SymNofX(-d1)
    Nd2 = SymNofX(-d2)
    return K*sympy.exp(-r*t)*Nd2-S*sympy.exp(-d*t)*Nd1

def PutGreeks(S0,K,tau,sigma,rf,d):
    
    SymK,SymS0,SymTau,SymSigma,SymRf,SymD = sympy.symbols('K S0 tau sigma rf d')
    OptionPrice = SymPutPrice(SymK,SymS0,SymSigma,SymTau,SymRf,SymD)
    
    Delta = diff(OptionPrice,SymS0)
    print(Delta)
    Gamma = diff(Delta,SymS0)
    Vega = diff(OptionPrice,SymSigma)
    Theta = -diff(OptionPrice,SymTau)
    Rho = diff(OptionPrice,SymRf)
    
    
    Del = Delta.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    print(N(Del))
    Gam = Gamma.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    Veg = Vega.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    Thet = Theta.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    Rh = Rho.subs({SymS0 : S0,SymK : K,SymTau : tau,SymSigma : sigma,SymRf : rf,SymD : d})
    
    return N(Del),N(Gam),N(Veg),N(Thet),N(Rh)

