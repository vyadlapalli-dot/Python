#!/usr/bin/env python
# coding: utf-8

#Missing values are filled with the first date for initial days outside the calender period

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pandas_datareader as web
import datetime as dt

def candlestick_plot(Ticker,ShortWindow=5,LongWindow=15):
    try:    
        today = dt.date.today()
        deltaT = dt.timedelta(days=60)
        frm = today - deltaT
        
        Data = web.get_data_yahoo(Ticker,start=frm.strftime("%m-%d-%Y"),end=today.strftime("%m-%d-%Y"))
        
        #Candlestick properties determined
        x=np.arange(len(Data.index))
        b=Data['Open']
        h=Data['Close']-Data['Open']
        a=10*x
        highs = []
        lows=[]
        for i in range(len(x)):
            if Data['Open'][i]>Data['Close'][i]:
                highs.append(Data['High'][i]-Data['Open'][i]-h[i])
                lows.append(Data['Close'][i]-Data['Low'][i])
            else:
                highs.append(Data['High'][i]-Data['Open'][i])
                lows.append(Data['Close'][i]-Data['Low'][i]+h[i])
        
        #Calculating Moving Average
        Init = Data['Close'][0]
                
        #Short Window
        Closes = []
        for i in range(ShortWindow-1):
            Closes.append(Init)
        for i in range(Data.shape[0]):
            Closes.append(Data['Close'][i])
        
        SMA = []
        
        for i in range(Data.shape[0]):
            LocAvg = np.asarray(Closes[i:i+ShortWindow])
            LocAvg = np.sum(LocAvg)
            LocAvg = LocAvg/ShortWindow
            SMA.append(LocAvg)
        
        Closes = []
        #Long Window
        for i in range(LongWindow-1):
            Closes.append(Init)
        for i in range(Data.shape[0]):
            Closes.append(Data['Close'][i])
        
        LMA = []
        
        for i in range(Data.shape[0]):
            LocAvg = np.asarray(Closes[i:i+LongWindow])
            LocAvg = np.sum(LocAvg)
            LocAvg = LocAvg/LongWindow
            LMA.append(LocAvg)
        
        limits = [lows,highs]
                
        plt.figure(figsize=(8,6))
        cstick=plt.bar(x,h,bottom=b,yerr=limits)
        plt.minorticks_on()
        plt.grid(b=True, which='major', color='b', linestyle='-')
        plt.grid(b=True, which='minor', color='r', linestyle='--')
        plt.xlabel('Date Range :'+frm.strftime("%m-%d-%Y")+' - '+today.strftime("%m-%d-%Y"))
        plt.ylabel('Price $')
        plt.plot(x,SMA,label=str(ShortWindow)+'-day Moving Average')
        plt.plot(x,LMA,label=str(LongWindow)+'-day Moving Average')
        plt.legend()
        for i in range(len(x)):
            if Data['Open'][i]>Data['Close'][i]:
                cstick[i].set_color('r')
            else:
                cstick[i].set_color('g')
        plt.savefig(Ticker+'_box.png')
           
        plt.figure(figsize=(8,4))
        vol = plt.bar(x,Data['Volume']/1000000)
        plt.xlabel('Date Range :'+frm.strftime("%m-%d-%Y")+' - '+today.strftime("%m-%d-%Y"))
        plt.ylabel('Traded Volume (in millions)')
        plt.savefig(Ticker+'_bar.png')
   
    except:
        print('Error')

candlestick_plot('AMZN',ShortWindow = 3,LongWindow = 10)

candlestick_plot('TSLA')
